package com.example.myapplication


import android.animation.*
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val ovalGreen = findViewById<ImageView>(R.id.circle_green)
        val ovalBlue = findViewById<ImageView>(R.id.circle_blue)


        val rotationAnimator = ValueAnimator.ofFloat(0f, 360f)
        rotationAnimator.duration = 50000
        rotationAnimator.repeatMode = ValueAnimator.RESTART
        rotationAnimator.repeatCount = ValueAnimator.INFINITE
        rotationAnimator.addUpdateListener { animation ->
            val value = animation.animatedValue as Float
            ovalGreen.rotation = value
            ovalBlue.rotation = value
        }

        val animator = ValueAnimator.ofFloat(0f, 1f, 0f)
        animator.duration = 50000
        animator.repeatMode = ValueAnimator.RESTART
        animator.repeatCount = ValueAnimator.INFINITE
        animator.addUpdateListener { animation ->
            val value = animation.animatedValue as Float
            ovalGreen.translationX = 1700 * value
            ovalBlue.translationX = -1700 * value
        }

        val mainAnimatorSet = AnimatorSet()
        mainAnimatorSet.playTogether(rotationAnimator, animator)
        mainAnimatorSet.start()


    }
}